import { motion } from 'motion/react';
import { LevelData, TileData } from '../types';
import { Gem, Scroll, ShieldAlert, ArrowRight, RotateCcw } from 'lucide-react';

interface EndScreenProps {
  level: LevelData;
  tiles: TileData[];
  onPlayAgain: () => void;
}

export default function EndScreen({ level, tiles, onPlayAgain }: EndScreenProps) {
  const totalGems = level.tiles.filter(t => t.type === 'gem').length;
  const collectedItems = tiles.filter(t => t.revealed && ['gem', 'lore', 'trap'].includes(t.type));
  const collectedGemsCount = collectedItems.filter(t => t.type === 'gem').length;
  
  const score = Math.round((collectedGemsCount / totalGems) * 100);

  return (
    <div className="flex-1 overflow-y-auto w-full h-full p-6 relative">
      <div className="max-w-2xl mx-auto py-8">
        
        {/* Header */}
        <div className="text-center mb-10">
          <h2 className="text-sm font-sans text-gray-400 uppercase tracking-widest mb-2">
            Session Complete
          </h2>
          <h1 className="text-4xl font-sans font-bold text-white mb-4 shadow-[var(--primary)]/50 drop-shadow-[0_0_15px_rgba(var(--primary-rgb),0.5)]">
            GEM BAG
          </h1>
          <div className="flex items-center justify-center gap-6">
            <div className="flex items-center gap-2">
              <div className="w-5 h-6 hex-clip bg-theme-primary shadow-[0_0_15px_rgba(var(--primary-rgb),1)]"></div>
              <span className="text-xl font-bold font-courier text-theme-primary text-shadow-glow">{collectedGemsCount} / {totalGems}</span>
            </div>
            <div className="w-px h-6 bg-[rgba(255,255,255,0.2)]" />
            <div className="flex flex-col items-start">
              <span className="text-xs text-gray-500 font-sans uppercase">Score</span>
              <span className="text-xl text-theme-primary font-bold font-courier text-shadow-glow">{score}%</span>
            </div>
          </div>
        </div>

        {/* Collection Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-12">
          {collectedItems.length === 0 ? (
            <div className="col-span-1 md:col-span-2 text-center py-10 bg-[#13131c] rounded-xl border border-[#333355]">
              <p className="text-gray-500 font-mono text-sm">No gems collected this time.</p>
            </div>
          ) : (
            collectedItems.map((item, i) => (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                key={item.id} 
                className={`p-5 rounded-xl border ${
                  item.type === 'trap' ? 'bg-[var(--trap)]/30 border-[var(--trap)]/30' :
                  item.type === 'lore' ? 'bg-theme-secondary/20 border-theme-secondary/30' :
                  'bg-[rgba(var(--primary-rgb),0.05)] border-[rgba(var(--primary-rgb),0.3)] shadow-[inset_0_0_10px_rgba(var(--primary-rgb),0.05)]'
                }`}
              >
                <div className="flex items-center gap-3 mb-3">
                  {item.type === 'gem' && <div className="w-4 h-5 flex-shrink-0 hex-clip bg-theme-primary shadow-[0_0_10px_rgba(var(--primary-rgb),1)]"></div>}
                  {item.type === 'lore' && <Scroll className="w-5 h-5 text-theme-secondary" />}
                  {item.type === 'trap' && <ShieldAlert className="w-5 h-5 text-[var(--trap)]" />}
                  <h3 className="font-bold text-gray-100">{item.title}</h3>
                </div>
                
                <div className="text-sm text-gray-400">
                  {item.type === 'trap' ? (
                    <>
                      <p className="text-red-400/80 mb-1 line-through">{item.mistake}</p>
                      <p className="text-gray-300">{item.correction}</p>
                    </>
                  ) : (
                    <p>{item.content}</p>
                  )}
                </div>
              </motion.div>
            ))
          )}
        </div>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row gap-4 items-center justify-center">
          <button 
            onClick={onPlayAgain}
            className="flex items-center gap-2 px-10 py-[14px] rounded-lg bg-transparent text-theme-primary border border-theme-primary/30 hover:bg-[rgba(var(--primary-rgb),0.1)] font-sans font-bold text-sm tracking-[1px] uppercase transition-all w-full sm:w-auto justify-center"
          >
            <RotateCcw className="w-4 h-4" /> PLAY AGAIN
          </button>
          <button 
            onClick={() => alert("Continuing to Practice...")}
            className="flex items-center gap-2 px-10 py-[14px] rounded-lg bg-theme-primary text-theme-bg font-sans font-bold text-sm tracking-[1px] uppercase transition-transform hover:scale-105 w-full sm:w-auto justify-center shadow-[0_0_20px_rgba(var(--primary-rgb),0.3)]"
          >
            CONTINUE PRACTICE <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
}
