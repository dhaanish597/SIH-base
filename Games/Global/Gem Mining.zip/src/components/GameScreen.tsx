import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Pickaxe, Gem, ShieldAlert, Scroll } from 'lucide-react';
import { LevelData, TileData } from '../types';
import { soundService } from '../services/soundService';

interface GameScreenProps {
  level: LevelData;
  onGameOver: (tiles: TileData[]) => void;
}

export default function GameScreen({ level, onGameOver }: GameScreenProps) {
  const [tiles, setTiles] = useState<TileData[]>(level.tiles.map(t => ({ ...t, revealed: false })));
  const [pickaxes, setPickaxes] = useState(15);
  const [gemsFound, setGemsFound] = useState(0);
  
  // Modal state
  const [activeCard, setActiveCard] = useState<TileData | null>(null);
  
  // X-Ray mode
  const [isXRay, setIsXRay] = useState(false);

  const totalGems = level.tiles.filter(t => t.type === 'gem').length;

  // Handle tile click
  const handleTileClick = (index: number) => {
    if (pickaxes <= 0 || isXRay || activeCard) return;
    const tile = tiles[index];
    if (tile.revealed) return;

    if (tile.type === 'trap') {
      soundService.playTrapSound();
    } else if (tile.type === 'gem' || tile.type === 'lore' || tile.type === 'boost') {
      soundService.playGemSound();
    } else {
      soundService.playStrikeSound();
    }

    // Mark revealed
    const newTiles = [...tiles];
    newTiles[index] = { ...tile, revealed: true };
    setTiles(newTiles);

    let newPickaxes = pickaxes - 1;

    // Boost effect
    if (tile.type === 'boost') {
      newPickaxes += 3; // Costs 1, gives +3 -> net +2
    }

    setPickaxes(newPickaxes);

    if (tile.type === 'gem') {
      setGemsFound(prev => prev + 1);
    }

    // Show card if not dirt or boost
    if (tile.type === 'gem' || tile.type === 'lore' || tile.type === 'trap') {
      setActiveCard(newTiles[index]);
    } else {
      // Check for Game Over immediately if it's just dirt/boost
      if (newPickaxes <= 0 || gemsFound === totalGems) {
        triggerGameOver(newTiles);
      }
    }
  };

  const handleCloseCard = () => {
    setActiveCard(null);
    // Check game over right after closing if 0 pickaxes or all gems found
    if (pickaxes <= 0 || gemsFound === totalGems) {
      triggerGameOver(tiles);
    }
  };

  const triggerGameOver = (currentTiles: TileData[]) => {
    setIsXRay(true);
    setTimeout(() => {
      onGameOver(currentTiles);
    }, 4500); // Wait 4.5 seconds to show X-Ray
  };

  return (
    <div className="flex-1 flex flex-col relative w-full h-full max-w-lg mx-auto pb-10">
      
      {/* Background Effect */}
      <div className="absolute inset-0 bg-theme-bg -z-20 transition-colors duration-500" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-[var(--card-bg-1)] to-transparent opacity-50 -z-10 transition-colors duration-500" />

      {/* TOP HUD */}
      <div className="flex justify-between items-center px-6 py-6 mt-4 z-10 relative">
        {/* Strikes */}
        <div className="flex items-center gap-3 text-theme-primary font-courier font-bold text-2xl text-shadow-glow transition-colors duration-500">
          <span>⛏</span>
          <span>
            {pickaxes}
          </span>
        </div>

        {/* Gems */}
        <div className="flex gap-2">
          {Array.from({ length: totalGems }).map((_, i) => (
            <div 
              key={i} 
              className={`w-5 h-6 hex-clip transition-all duration-500 ${i < gemsFound ? 'bg-theme-primary shadow-[0_0_15px_rgba(var(--primary-rgb),1)]' : 'bg-white/5 border border-white/10'}`} 
            />
          ))}
        </div>
      </div>

      {/* Topic Pill */}
      <div className="flex justify-center mb-[60px] z-10 relative">
        <div className="bg-theme-secondary/10 border border-theme-secondary/50 px-6 py-2 rounded-full shadow-[0_0_20px_rgba(var(--secondary-rgb),0.2)] transition-colors duration-500">
          <span className="text-theme-secondary font-sans font-semibold text-sm tracking-[2px] uppercase transition-colors duration-500">
            {level.topic}
          </span>
        </div>
      </div>

      {/* Grid container */}
      <div className="flex-1 flex items-center justify-center px-4 w-full relative">
        <div className="grid grid-cols-6 gap-2 w-full max-w-[400px] aspect-square">
          {tiles.map((tile, i) => (
            <Tile 
              key={tile.id}
              tile={tile}
              isXRay={isXRay}
              onClick={() => handleTileClick(i)}
            />
          ))}
        </div>
      </div>

      {/* Card Modal */}
      <AnimatePresence>
        {activeCard && (
          <PopCard tile={activeCard} onClose={handleCloseCard} />
        )}
      </AnimatePresence>
      
      {/* Trap red flash overlay */}
      <AnimatePresence>
        {activeCard?.type === 'trap' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.15, backgroundColor: 'var(--trap)' }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 pointer-events-none z-40"
          />
        )}
      </AnimatePresence>
    </div>
  );
}

// ----------------------------------------------------------------------
// Subcomponents
// ----------------------------------------------------------------------

interface TileProps {
  key?: string | number;
  tile: TileData;
  isXRay: boolean;
  onClick: () => void;
}

function Tile({ tile, isXRay, onClick }: TileProps) {
  // Compute style depending on state
  let bg = "bg-gradient-to-br from-[var(--card-bg-1)] to-[var(--card-bg-2)]";
  let border = "border-b-[4px] border-r-[4px] border-black shadow-[inset_0_2px_4px_rgba(255,255,255,0.05)] rounded-[4px]";
  let icon = null;

  if (tile.revealed) {
    if (tile.type === 'dirt') {
      bg = "bg-[var(--theme-dirt-bg,#2B1D12)]";
      border = "border-t-[2px] border-[var(--theme-dirt-border,#1A110B)] shadow-[inset_0_5px_15px_rgba(0,0,0,0.6)] rounded-[4px]";
      icon = "🪨";
    } else if (tile.type === 'gem') {
      bg = "bg-theme-primary shadow-[0_0_30px_rgba(var(--primary-rgb),0.8)]";
      border = "border-none rounded-[4px]";
      icon = "💎";
    } else if (tile.type === 'lore') {
      bg = "bg-theme-secondary shadow-[0_0_30px_rgba(var(--secondary-rgb),0.8)]";
      border = "border-none rounded-[4px]";
      icon = "📜";
    } else if (tile.type === 'trap') {
      bg = "bg-[var(--trap)] shadow-[0_0_30px_rgba(var(--trap-rgb),0.8)]";
      border = "border-none rounded-[4px]";
      icon = "💥";
    } else if (tile.type === 'boost') {
      bg = "bg-[#FFC93C] shadow-[0_0_30px_#FFC93C]";
      border = "border-none rounded-[4px]";
      icon = "⚡";
    }
  } else if (isXRay) {
    // Show xray hint for missed items
    if (tile.type === 'gem') {
      border = "border border-theme-primary shadow-[0_0_10px_2px_rgba(var(--primary-rgb),0.4)] rounded-[4px]";
      icon = <Gem className="w-5 h-5 text-theme-primary opacity-50 absolute" />;
    } else if (tile.type === 'trap') {
       border = "border border-[var(--trap)]/50 rounded-[4px]";
    }
  }

  // Animation variants for breaking a tile
  const particleCount = tile.revealed && tile.type !== 'dirt' ? 8 : 4;
  
  return (
    <motion.button
      whileTap={!tile.revealed && !isXRay ? { scale: 0.85 } : {}}
      onClick={onClick}
      disabled={tile.revealed || isXRay}
      className={`relative w-full aspect-square flex items-center justify-center text-xl sm:text-2xl transition-all duration-200 ${bg} ${border} overflow-hidden`}
    >
      {/* Particles effect when revealed */}
      {tile.revealed && (
        <div className="absolute inset-0 pointer-events-none">
          {Array.from({ length: particleCount }).map((_, pIndex) => {
            const angle = (pIndex / particleCount) * Math.PI * 2;
            const distance = Math.random() * 30 + 10;
            const x = Math.cos(angle) * distance;
            const y = Math.sin(angle) * distance;
            return (
              <motion.div
                key={pIndex}
                initial={{ x: 0, y: 0, opacity: 1, scale: 0.5 }}
                animate={{ x, y: y + 20, opacity: 0, scale: 0 }}
                transition={{ duration: 0.5, ease: "easeOut" }}
                className="absolute left-1/2 top-1/2 w-2 h-2 rounded-sm bg-white mix-blend-overlay"
                style={{ marginLeft: -4, marginTop: -4 }}
              />
            );
          })}
        </div>
      )}
      
      {/* Icon with pop animation */}
      {tile.revealed && (
        <motion.div
           initial={{ opacity: 0, scale: 0.2, rotate: -20 }}
           animate={{ opacity: 1, scale: 1, rotate: 0 }}
           transition={{ type: "spring", bounce: 0.5, duration: 0.6 }}
           className="relative z-10"
        >
          {icon}
        </motion.div>
      )}
      {!tile.revealed && isXRay && icon}
    </motion.button>
  );
}

function PopCard({ tile, onClose }: { tile: TileData; onClose: () => void }) {
  let accent = "text-theme-primary";
  let glowColor = "var(--primary-rgb)";
  let bgOuter = "bg-theme-primary";
  let outline = "border-theme-primary/30";
  let Icon = Gem;
  let header = "GEM DISCOVERED";
  
  if (tile.type === 'trap') {
    accent = "text-[var(--trap)]";
    glowColor = "var(--trap-rgb)";
    bgOuter = "bg-[var(--trap)]";
    outline = "border-[var(--trap)]/30";
    Icon = ShieldAlert;
    header = "WARNING - TRAP!";
  } else if (tile.type === 'lore') {
    accent = "text-theme-secondary";
    glowColor = "var(--secondary-rgb)";
    bgOuter = "bg-theme-secondary";
    outline = "border-theme-secondary/30";
    Icon = Scroll;
    header = "LORE DISCOVERED";
  }

  return (
    <div className="absolute inset-0 z-50 flex flex-col justify-end pointer-events-auto">
      {/* Backdrop */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-[rgba(7,7,15,0.85)] flex items-center justify-center"
      >
        {/* Card centered in the new design */}
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 50, opacity: 0 }}
          transition={{ type: "spring", damping: 25, stiffness: 200 }}
          className={`relative w-full max-w-[420px] bg-gradient-to-b from-[var(--card-bg-1)] to-[var(--card-bg-2)] border ${outline} rounded-2xl p-8 flex flex-col items-center justify-center text-center shadow-[0_0_60px_rgba(${glowColor},0.15),inset_0_0_20px_rgba(${glowColor},0.05)] mx-4`}
          onClick={(e) => e.stopPropagation()}
        >
          {/* Sparkles */}
          <div className="absolute w-[2px] h-[2px] bg-white rounded-full shadow-[0_0_10px_#fff] top-[20%] left-[15%]" />
          <div className="absolute w-[2px] h-[2px] bg-white rounded-full shadow-[0_0_10px_#fff] top-[40%] right-[10%]" />
          <div className="absolute w-[2px] h-[2px] bg-white rounded-full shadow-[0_0_10px_#fff] bottom-[25%] left-[10%]" />
          
          <div className={`w-16 h-20 hex-clip ${bgOuter} flex items-center justify-center mb-6 shadow-[0_0_30px_rgba(${glowColor},0.6)]`}>
            <Icon className="w-8 h-8 text-[var(--bg)]" />
          </div>
          
          <h2 className="text-2xl font-bold text-white tracking-[0.5px] mb-3">
            {tile.title}
          </h2>
          
          <div className="text-[16px] leading-[1.6] text-white/70 mb-8 max-w-sm px-[10px]">
            {tile.type === 'trap' ? (
              <>
                <p className="text-red-300 font-medium mb-2">Common Mistake: {tile.mistake}</p>
                <p>Correction: {tile.correction}</p>
              </>
            ) : (
              <p>{tile.content}</p>
            )}
          </div>

          <button
            onClick={onClose}
            className={`w-auto px-10 py-[14px] rounded-lg font-bold text-sm tracking-[1px] uppercase transition-transform hover:scale-105 shadow-[0_0_20px_rgba(${glowColor},0.3)]
              ${tile.type === 'trap' ? 'bg-[var(--trap)] text-[var(--bg)]' : 
                tile.type === 'lore' ? 'bg-theme-secondary text-[var(--bg)]' : 
                'bg-theme-primary text-[var(--bg)]'}`}
          >
            {tile.type === 'trap' ? 'I Will Remember' : 'Collect ' + (tile.type === 'gem' ? '💎' : '📜')}
          </button>
        </motion.div>
      </motion.div>
    </div>
  );
}
