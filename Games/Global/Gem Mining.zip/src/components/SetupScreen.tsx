import React, { useState } from 'react';
import { generateLevel } from '../services/geminiService';
import { LevelData } from '../types';
import { Pickaxe, Loader2, Volume2, VolumeX, Palette, HelpCircle, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { soundService } from '../services/soundService';

interface SetupScreenProps {
  onStart: (data: LevelData) => void;
  currentTheme: string;
  onThemeChange: (theme: string) => void;
}

export default function SetupScreen({ onStart, currentTheme, onThemeChange }: SetupScreenProps) {
  const [topic, setTopic] = useState('Quadratic Equations');
  const [grade, setGrade] = useState('10');
  const [subject, setSubject] = useState('Mathematics');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showTutorial, setShowTutorial] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(soundService.isEnabled());

  const toggleSound = () => {
    setSoundEnabled(soundService.toggle());
  };

  const themes = [
    { id: 'default', name: 'Pro Polish' },
    { id: 'emerald', name: 'Emerald' },
    { id: 'cyber', name: 'Cyber Neon' }
  ];

  const handleStart = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic || !grade || !subject) return;

    setLoading(true);
    setError('');
    
    try {
      const data = await generateLevel(topic, parseInt(grade), subject);
      onStart(data);
    } catch (err) {
      console.error(err);
      setError('Failed to generate the level. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col items-center justify-center p-6 relative overflow-hidden transition-colors duration-500">
      
      {/* Background decor */}
      <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none -z-10 transition-colors duration-500">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-theme-primary blur-[150px] rounded-full mix-blend-screen transition-colors duration-500" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-theme-secondary blur-[150px] rounded-full mix-blend-screen transition-colors duration-500" />
      </div>

      {/* Top right controls */}
      <div className="absolute top-6 right-6 flex gap-3 z-20">
        <button 
          onClick={toggleSound}
          className="p-2 rounded-lg bg-[rgba(var(--primary-rgb),0.1)] border border-[rgba(var(--primary-rgb),0.3)] text-theme-primary hover:bg-[rgba(var(--primary-rgb),0.2)] transition-colors transition-transform duration-200 hover:scale-105"
        >
          {soundEnabled ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
        </button>
        <button 
          onClick={() => setShowTutorial(true)}
          className="p-2 rounded-lg bg-[rgba(var(--primary-rgb),0.1)] border border-[rgba(var(--primary-rgb),0.3)] text-theme-primary hover:bg-[rgba(var(--primary-rgb),0.2)] transition-colors transition-transform duration-200 hover:scale-105"
        >
          <HelpCircle className="w-5 h-5" />
        </button>
        
        <div className="relative group">
          <button className="p-2 rounded-lg bg-[rgba(var(--primary-rgb),0.1)] border border-[rgba(var(--primary-rgb),0.3)] text-theme-primary hover:bg-[rgba(var(--primary-rgb),0.2)] transition-colors flex items-center gap-2">
            <Palette className="w-5 h-5" />
          </button>
          <div className="absolute top-full right-0 mt-2 py-2 w-36 bg-[#13131c] border border-theme-primary/30 rounded-lg shadow-xl opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all">
            {themes.map(t => (
              <button 
                key={t.id}
                type="button"
                className={`block w-full text-left px-4 py-2 hover:bg-theme-primary/20 hover:text-theme-primary transition-colors text-sm ${currentTheme === t.id ? 'text-theme-primary font-bold' : 'text-gray-400'}`}
                onClick={() => onThemeChange(t.id)}
              >
                {t.name}
              </button>
            ))}
          </div>
        </div>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md bg-[#13131c] border border-[rgba(var(--primary-rgb),0.3)] rounded-2xl p-8 relative z-10 transition-colors duration-500"
      >
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-[rgba(var(--primary-rgb),0.1)] border border-[rgba(var(--primary-rgb),0.3)] rounded-xl flex items-center justify-center shadow-[0_0_30px_rgba(var(--primary-rgb),0.3)] transition-colors duration-500">
              <Pickaxe className="w-8 h-8 text-theme-primary transition-colors duration-500" />
            </div>
          </div>
          <h1 className="text-3xl font-sans font-bold text-white mb-2 tracking-wide text-shadow-glow">
            QUEST ACADEMY
          </h1>
          <p className="text-gray-400 font-sans text-sm">
            Deep in the Learning Mines
          </p>
        </div>

        <form onSubmit={handleStart} className="space-y-5">
          <div>
            <label className="block text-xs font-mono text-gray-500 uppercase tracking-widest mb-2 font-semibold">
              Topic
            </label>
            <input
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              className="w-full bg-[#0a0a10] border border-[#333355] rounded-lg px-4 py-3 text-white focus:outline-none focus:border-[#8b5cf6] transition-colors"
              placeholder="e.g. Quadratic Equations"
              required
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-mono text-gray-500 uppercase tracking-widest mb-2 font-semibold">
                Grade
              </label>
              <input
                type="number"
                value={grade}
                onChange={(e) => setGrade(e.target.value)}
                className="w-full bg-[#0a0a10] border border-[#333355] rounded-lg px-4 py-3 text-white focus:outline-none focus:border-[#8b5cf6] transition-colors"
                min="1"
                max="12"
                required
              />
            </div>
            <div>
              <label className="block text-xs font-mono text-gray-500 uppercase tracking-widest mb-2 font-semibold">
                Subject
              </label>
              <input
                type="text"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
                className="w-full bg-[#0a0a10] border border-[#333355] rounded-lg px-4 py-3 text-white focus:outline-none focus:border-[#8b5cf6] transition-colors"
                placeholder="e.g. Math"
                required
              />
            </div>
          </div>

          {error && (
            <p className="text-red-400 text-sm bg-red-900/20 py-2 px-3 rounded-md border border-red-900/50">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full mt-6 bg-theme-primary text-theme-bg font-sans tracking-[1px] py-4 rounded-xl disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 font-bold uppercase transition-transform hover:scale-[1.02] shadow-[0_0_20px_rgba(var(--primary-rgb),0.4)]"
          >
            {loading ? (
              <span className="flex items-center justify-center gap-2">
                <Loader2 className="w-5 h-5 animate-spin" /> Digging...
              </span>
            ) : (
              'Enter the Mine'
            )}
          </button>
        </form>
      </motion.div>

      <AnimatePresence>
        {showTutorial && (
          <div className="absolute inset-0 z-50 flex items-center justify-center p-4 pointer-events-auto">
            <motion.div 
              initial={{ bgOpacity: 0 }}
              animate={{ backgroundColor: 'rgba(7,7,15,0.85)' }}
              exit={{ backgroundColor: 'rgba(7,7,15,0)' }}
              onClick={() => setShowTutorial(false)}
              className="absolute inset-0"
            />
            
            <motion.div
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 50, opacity: 0 }}
              className="relative w-full max-w-[500px] bg-gradient-to-b from-[var(--card-bg-1)] to-[var(--card-bg-2)] border border-[rgba(var(--primary-rgb),0.3)] rounded-2xl p-8 flex flex-col mx-4 shadow-[0_0_60px_rgba(var(--primary-rgb),0.15)] max-h-[85vh] overflow-y-auto"
            >
              <button 
                onClick={() => setShowTutorial(false)}
                className="absolute top-4 right-4 text-gray-400 hover:text-white"
              >
                <X className="w-6 h-6" />
              </button>

              <h2 className="text-2xl font-bold text-theme-primary mb-6 pt-2">How to Play</h2>
              
              <div className="space-y-6">
                <div className="flex gap-4">
                  <div className="w-12 h-12 bg-theme-primary/20 border border-theme-primary/50 text-theme-primary rounded-lg flex items-center justify-center text-xl flex-shrink-0">💎</div>
                  <div>
                    <h3 className="font-bold text-white mb-1">Gems (Facts)</h3>
                    <p className="text-gray-400 text-sm leading-relaxed">Most tiles hide facts. Finding a gem reveals a crucial piece of knowledge. Collect them all to win!</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="w-12 h-12 bg-theme-secondary/20 border border-theme-secondary/50 text-theme-secondary rounded-lg flex items-center justify-center text-xl flex-shrink-0">📜</div>
                  <div>
                    <h3 className="font-bold text-white mb-1">Lore</h3>
                    <p className="text-gray-400 text-sm leading-relaxed">Shows history or interesting context. These give you a wider view of the topic.</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="w-12 h-12 bg-[#EF4444]/20 border border-[#EF4444]/50 text-[#EF4444] rounded-lg flex items-center justify-center text-xl flex-shrink-0">💥</div>
                  <div>
                    <h3 className="font-bold text-white mb-1">Traps (Misconceptions)</h3>
                    <p className="text-gray-400 text-sm leading-relaxed">Traps reveal common mistakes students make. Hitting a trap is surprisingly helpful for learning, but costs a turn!</p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="w-12 h-12 bg-[#FFC93C]/20 border border-[#FFC93C]/50 text-[#FFC93C] rounded-lg flex items-center justify-center text-xl flex-shrink-0">⚡</div>
                  <div>
                    <h3 className="font-bold text-white mb-1">Picks (Boosts)</h3>
                    <p className="text-gray-400 text-sm leading-relaxed">Finding a boost grants you extra pickaxe strikes, extending your exploration.</p>
                  </div>
                </div>
              </div>

              <button
                onClick={() => setShowTutorial(false)}
                className="mt-8 w-full bg-theme-primary text-theme-bg py-3 rounded-lg font-bold tracking-wide uppercase transition-transform hover:scale-105"
              >
                Got It
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
