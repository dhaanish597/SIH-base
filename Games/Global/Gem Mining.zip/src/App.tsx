import { useState, useEffect } from 'react';
import SetupScreen from './components/SetupScreen';
import GameScreen from './components/GameScreen';
import EndScreen from './components/EndScreen';
import { LevelData, TileData } from './types';
import { soundService } from './services/soundService';

export default function App() {
  const [gameState, setGameState] = useState<'setup' | 'playing' | 'end'>('setup');
  const [levelData, setLevelData] = useState<LevelData | null>(null);
  
  // Track tiles played
  const [playedTiles, setPlayedTiles] = useState<TileData[]>([]);

  // Theme support
  const [theme, setTheme] = useState('default');

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  const handleStartPlay = (data: LevelData) => {
    setLevelData(data);
    setGameState('playing');
  };

  const handleGameOver = (finalTiles: TileData[]) => {
    setPlayedTiles(finalTiles);
    setGameState('end');
  };

  const handlePlayAgain = () => {
    setGameState('setup');
    setLevelData(null);
    setPlayedTiles([]);
  };

  return (
    <div className="min-h-screen bg-theme-bg text-white flex flex-col font-sans overflow-hidden transition-colors duration-500">
      {gameState === 'setup' && (
        <SetupScreen 
          onStart={handleStartPlay} 
          currentTheme={theme} 
          onThemeChange={setTheme} 
        />
      )}
      
      {gameState === 'playing' && levelData && (
        <GameScreen level={levelData} onGameOver={handleGameOver} />
      )}
      
      {gameState === 'end' && levelData && (
        <EndScreen 
          level={levelData} 
          tiles={playedTiles} 
          onPlayAgain={handlePlayAgain} 
        />
      )}
    </div>
  );
}
