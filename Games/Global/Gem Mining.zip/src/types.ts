export type TileType = 'gem' | 'lore' | 'trap' | 'boost' | 'dirt' | 'hidden';

export interface TileData {
  id: number;
  type: TileType;
  title?: string;
  content?: string;
  mistake?: string;
  correction?: string;
  revealed?: boolean;
}

export interface LevelData {
  topic: string;
  grade: number;
  subject: string;
  tiles: TileData[];
}
