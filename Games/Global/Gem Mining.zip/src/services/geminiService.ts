import { GoogleGenAI } from "@google/genai";
import { TileData, LevelData } from "../types";

// Initialize the Gemini client
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

export async function generateLevel(topic: string, grade: number, subject: string): Promise<LevelData> {
  const prompt = `You are creating content for a Gem Mining exploration game in a school learning app called Quest Academy.
Students aged 13-17 will tap tiles on a 6x6 grid to discover hidden content. There are NO questions asked. All learning happens through discovery.

Topic: ${topic}
Grade: ${grade}
Subject: ${subject}

Generate the textual content for the tiles.
You must provide exactly:
- 8 gems: Each reveals a key fact. Start with a bold title, then 2 sentences. Teach distinct concepts progressively.
- 4 lores: Real-world hook or application. 2-3 sentences.
- 3 traps: Common misconception. Show mistake first, then correction.

Return ONLY valid JSON matching this schema:
{
  "gems": [
    { "title": "Gem Title", "content": "Gem fact..." }
  ],
  "lores": [
    { "title": "Lore Title", "content": "Lore content..." }
  ],
  "traps": [
    { "title": "Trap Title", "mistake": "The mistake...", "correction": "The correction..." }
  ]
}`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3.1-pro-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      }
    });

    let rawText = response.text || "{}";
    rawText = rawText.replace(/```json/g, '').replace(/```/g, '').trim();
    
    const parsed = JSON.parse(rawText);
    
    // Assemble the 36 tiles
    const allTiles: TileData[] = [];
    let idCounter = 1;

    // Add gems
    if (parsed.gems) {
      parsed.gems.forEach((gem: any) => {
        allTiles.push({
          id: idCounter++,
          type: 'gem',
          title: gem.title,
          content: gem.content
        });
      });
    }

    // Add lores
    if (parsed.lores) {
      parsed.lores.forEach((lore: any) => {
        allTiles.push({
          id: idCounter++,
          type: 'lore',
          title: lore.title,
          content: lore.content
        });
      });
    }

    // Add traps
    if (parsed.traps) {
      parsed.traps.forEach((trap: any) => {
        allTiles.push({
          id: idCounter++,
          type: 'trap',
          title: trap.title,
          mistake: trap.mistake,
          correction: trap.correction
        });
      });
    }

    // We should have 15 structured tiles now. 
    // We need 2 boost tiles and 19 dirt tiles.
    for (let i = 0; i < 2; i++) {
      allTiles.push({
        id: idCounter++,
        type: 'boost'
      });
    }

    // Fill the rest with dirt to exactly 36 tiles
    const remaining = 36 - allTiles.length;
    for (let i = 0; i < remaining; i++) {
      allTiles.push({
        id: idCounter++,
        type: 'dirt'
      });
    }

    // Shuffle tiles
    for (let i = allTiles.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [allTiles[i], allTiles[j]] = [allTiles[j], allTiles[i]];
    }

    return {
      topic,
      grade,
      subject,
      tiles: allTiles
    };
    
  } catch (err) {
    console.error("Failed to generate level:", err);
    throw err;
  }
}
