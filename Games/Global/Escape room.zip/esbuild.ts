import * as esbuild from 'esbuild';

await esbuild.build({
  entryPoints: ['server.ts'],
  bundle: true,
  outfile: 'dist/server.cjs',
  platform: 'node',
  target: 'node20',
  external: ['express', 'vite', '@google/genai'], // Externalize node modules
});
