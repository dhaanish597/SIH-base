import React, { useState } from 'react';
import TowerDefenceGame from './components/games/TowerDefenceGame';
import CastleSprite from './components/games/CastleSprite';

export default function App() {
  const [playing, setPlaying] = useState(false);
  const [topicName, setTopicName] = useState("Quadratic Equations");
  const [grade, setGrade] = useState(10);
  const [score, setScore] = useState<number | null>(null);

  if (playing) {
    return (
      <TowerDefenceGame 
        topicId="topic-123"
        topicName={topicName}
        grade={grade}
        onComplete={(finalScore) => {
          setScore(finalScore);
          setPlaying(false);
        }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-sky-100 text-slate-800 flex flex-col items-center justify-center p-4 font-sans relative overflow-hidden">
      {/* Background Gamified Elements */}
      <div className="absolute top-10 left-10 text-6xl opacity-30 animate-pulse">☁️</div>
      <div className="absolute top-20 right-20 text-6xl opacity-30 animate-pulse" style={{ animationDelay: '1s'}}>☁️</div>
      <div className="absolute bottom-20 left-1/4 text-4xl opacity-50 animate-bounce">⭐</div>
      <div className="absolute top-1/3 right-1/4 text-3xl opacity-50 animate-bounce" style={{ animationDelay: '0.5s'}}>🍄</div>

      <div className="max-w-md w-full bg-white rounded-3xl shadow-[0_10px_40px_-10px_rgba(0,0,0,0.15)] p-8 border-4 border-sky-200 z-10 relative">
        <div className="text-center mb-8 flex flex-col items-center">
           <div className="w-32 mb-4">
             <CastleSprite />
           </div>
           <h1 className="text-4xl font-black mb-2 text-sky-600 tracking-tight">Tower Defence</h1>
           <p className="text-slate-500 font-bold">Stop the mobs by answering correctly!</p>
        </div>

        {score !== null && (
          <div className="mb-8 bg-sky-50 border-4 border-green-200 rounded-2xl p-4 text-center shadow-inner">
            <h3 className="text-xl font-black text-green-500 mb-1">Previous Score</h3>
            <div className="text-4xl font-black text-slate-700">{score}%</div>
          </div>
        )}

        <div className="space-y-4 mb-8">
          <div>
            <label className="block text-sm font-bold text-slate-600 mb-1 uppercase tracking-wider">Topic</label>
            <input 
              type="text" 
              value={topicName}
              onChange={(e) => setTopicName(e.target.value)}
              className="w-full bg-slate-50 border-2 border-slate-200 rounded-xl px-4 py-3 text-slate-800 font-bold focus:outline-none focus:border-sky-400 focus:ring-4 focus:ring-sky-100 transition-all"
            />
          </div>
          <div>
            <label className="block text-sm font-bold text-slate-600 mb-1 uppercase tracking-wider">Grade</label>
            <input 
              type="number" 
              min={1} max={12}
              value={grade}
              onChange={(e) => setGrade(parseInt(e.target.value) || 1)}
              className="w-full bg-slate-50 border-2 border-slate-200 rounded-xl px-4 py-3 text-slate-800 font-bold focus:outline-none focus:border-sky-400 focus:ring-4 focus:ring-sky-100 transition-all"
            />
          </div>
        </div>

        <button 
          onClick={() => setPlaying(true)}
          className="w-full bg-green-500 hover:bg-green-400 text-white font-black py-4 px-8 rounded-2xl shadow-[0_6px_0_0_#16a34a] hover:shadow-[0_4px_0_0_#16a34a] hover:translate-y-[2px] transition-all flex items-center justify-center gap-2 text-xl"
        >
          <span>Start Wave</span>
          <span className="text-2xl">⚡</span>
        </button>
      </div>
    </div>
  );
}
