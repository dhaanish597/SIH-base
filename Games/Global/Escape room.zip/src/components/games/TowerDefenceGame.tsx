'use client';
import React, { useState, useEffect, useRef } from 'react';
import './TowerDefenceGame.css';
import LoadingScreen from './LoadingScreen';
import RecapCard from './RecapCard';
import CastleSprite from './CastleSprite';

// ── Types ──────────────────────────────────────────────────────────────
export interface Question {
  id: number;
  question: string;
  correct: string;
  distractors: string[];
  explanation: string;
  difficulty: 'easy' | 'medium' | 'hard';
}

export interface GameQuestion extends Question {
  allOptions: string[]; // correct + shuffled distractors
  monsterSprite: string;
}

const SCARY_MONSTERS = ['👹', '👿', '💀', '👽', '👾', '🧛‍♂️', '🧟‍♂️', '👺', '🐍', '🕷️'];

interface TowerDefenceGameProps {
  topicId: string;
  topicName: string;
  grade: number;
  onComplete: (score: number) => void;
}

// ── Sound Manager ────────────────────────────────────────────────────────
const playSound = (type: 'correct' | 'wrong' | 'hit') => {
  try {
    const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const gainNode = audioCtx.createGain();
    const oscillator = audioCtx.createOscillator();
    
    oscillator.connect(gainNode);
    gainNode.connect(audioCtx.destination);
    
    const now = audioCtx.currentTime;
    
    if (type === 'correct') {
      // Happy upwards ping
      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(600, now);
      oscillator.frequency.exponentialRampToValueAtTime(1200, now + 0.1);
      gainNode.gain.setValueAtTime(0, now);
      gainNode.gain.linearRampToValueAtTime(0.2, now + 0.05);
      gainNode.gain.exponentialRampToValueAtTime(0.01, now + 0.3);
      oscillator.start(now);
      oscillator.stop(now + 0.3);
    } else if (type === 'wrong') {
      // Sad buzz
      oscillator.type = 'sawtooth';
      oscillator.frequency.setValueAtTime(150, now);
      oscillator.frequency.exponentialRampToValueAtTime(80, now + 0.2);
      gainNode.gain.setValueAtTime(0, now);
      gainNode.gain.linearRampToValueAtTime(0.2, now + 0.05);
      gainNode.gain.exponentialRampToValueAtTime(0.01, now + 0.4);
      oscillator.start(now);
      oscillator.stop(now + 0.4);
    } else if (type === 'hit') {
      // Big low thud for losing a life
      oscillator.type = 'square';
      oscillator.frequency.setValueAtTime(100, now);
      oscillator.frequency.exponentialRampToValueAtTime(40, now + 0.3);
      gainNode.gain.setValueAtTime(0, now);
      gainNode.gain.linearRampToValueAtTime(0.3, now + 0.05);
      gainNode.gain.exponentialRampToValueAtTime(0.01, now + 0.5);
      oscillator.start(now);
      oscillator.stop(now + 0.5);
    }
  } catch (e) {
    console.error("Audio play failed", e);
  }
};

// ── Component ──────────────────────────────────────────────────────────
export default function TowerDefenceGame({
  topicId, topicName, grade, onComplete
}: TowerDefenceGameProps) {

  const [phase, setPhase] = useState<'loading' | 'playing' | 'recap' | 'done'>('loading');
  const [questions, setQuestions] = useState<GameQuestion[]>([]);
  const [currentMobIndex, setCurrentMobIndex] = useState(0);
  const [mobPosition, setMobPosition] = useState(0);   // 0 = right edge, 100 = base
  const [lives, setLives] = useState(3);
  const [feedback, setFeedback] = useState<'correct' | 'wrong' | null>(null);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [wrongQuestions, setWrongQuestions] = useState<GameQuestion[]>([]);
  const [correctCount, setCorrectCount] = useState(0);
  const [xp, setXp] = useState(0);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  // ── Step 1: Load questions from Gemini on mount ─────────────────────
  useEffect(() => {
    loadQuestions();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function loadQuestions() {
    const prompt = buildGeminiPrompt(topicName, grade);
    try {
      const res = await fetch('/api/gemini/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt })
      });
      const data = await res.json();
      
      // Clean up markdown code block backticks if they exist
      let rawText = data.text;
      if (rawText.startsWith('```json')) {
         rawText = rawText.replace(/```json\n?/, '').replace(/\n?```$/, '');
      } else if (rawText.startsWith('```')) {
         rawText = rawText.replace(/```\n?/, '').replace(/\n?```$/, '');
      }
      
      const rawObj = JSON.parse(rawText);
      const raw: Question[] = rawObj.questions;
      
      const prepared = raw.map((q, idx) => ({
        ...q,
        allOptions: shuffle([q.correct, ...q.distractors]),
        monsterSprite: SCARY_MONSTERS[Math.floor(Math.random() * SCARY_MONSTERS.length)]
      }));
      setQuestions(prepared);
      setPhase('playing');
    } catch (e) {
      console.error(e);
      // Fallback: pull from existing Question model for this topic or use dummy data
      try {
        const fallback = await fetch(`/api/learn/content/${topicId}/PLAY`);
        const data = await fallback.json();
        if (data.questions && data.questions.length > 0) {
           const fallbackPrepared = data.questions.map((q: any) => ({
             ...q,
             monsterSprite: SCARY_MONSTERS[Math.floor(Math.random() * SCARY_MONSTERS.length)]
           }));
           setQuestions(fallbackPrepared);
        } else {
           throw new Error("No fallback questions");
        }
      } catch (fallbackError) {
        // Ultimate fallback data if API completely fails
        setQuestions([
          {
            id: 1, question: "Fallback question: 1 + 1?", correct: "2", distractors: ["3", "4", "5"], explanation: "1 + 1 is 2", difficulty: "easy", allOptions: ["2", "3", "4", "5"], monsterSprite: '👾'
          }
        ]);
      }
      setPhase('playing');
    }
  }

  // ── Step 2: Mob walks the path ──────────────────────────────────────
  const currentMob = questions[currentMobIndex];

  useEffect(() => {
    if (phase !== 'playing' || !currentMob || feedback) {
       if (intervalRef.current) clearInterval(intervalRef.current);
       return;
    }
    
    // Mob advances every 600ms. Speed by difficulty:
    const speed = currentMob.difficulty === 'easy' ? 800
                : currentMob.difficulty === 'medium' ? 550 : 380;

    intervalRef.current = setInterval(() => {
      setMobPosition(prev => {
        if (prev >= 100) {
          clearInterval(intervalRef.current!);
          handleMobReachedBase();
          return 100;
        }
        return prev + 2; // 2% per tick
      });
    }, speed);

    return () => clearInterval(intervalRef.current!);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentMobIndex, phase, feedback]);

  // ── Step 3: Answer handling ─────────────────────────────────────────
  function handleAnswer(option: string) {
    if (feedback) return; // locked while showing feedback
    if (intervalRef.current) clearInterval(intervalRef.current);
    setSelectedOption(option);

    if (option === currentMob.correct) {
      // Correct: kill mob
      setFeedback('correct');
      playSound('correct');
      if (!wrongQuestions.find(q => q.id === currentMob.id)) {
         setCorrectCount(c => c + 1);
         setXp(x => x + (currentMob.difficulty === 'hard' ? 30 : currentMob.difficulty === 'medium' ? 20 : 10));
      }
      
      setTimeout(() => {
        setFeedback(null);
        setSelectedOption(null);
        nextMob();
      }, 900);
    } else {
      // Wrong: mob advances 15%, show correction
      setFeedback('wrong');
      playSound('wrong');
      setMobPosition(p => Math.min(p + 15, 95));
      if (!wrongQuestions.find(q => q.id === currentMob.id)) {
        setWrongQuestions(wq => [...wq, currentMob]);
      }
      setTimeout(() => {
        setFeedback(null);
        setSelectedOption(null);
        // Mob still alive — player must answer again, interval resumes due to effect dep on `feedback`
      }, 2000);
    }
  }

  function handleMobReachedBase() {
    setFeedback('wrong'); // reuse wrong state for red visual
    playSound('hit');
    setLives(l => l - 1);
    
    if (!wrongQuestions.find(q => q.id === currentMob.id)) {
      setWrongQuestions(wq => [...wq, currentMob]);
    }
    
    setTimeout(() => {
      setFeedback(null);
      nextMob();
    }, 2500);
  }

  function nextMob() {
    setMobPosition(0);
    if (currentMobIndex + 1 >= questions.length) {
      setPhase('recap');
    } else {
      setCurrentMobIndex(i => i + 1);
    }
  }

  // Effect to check if player died after lives update
  useEffect(() => {
    if (lives <= 0 && phase === 'playing') {
       if (intervalRef.current) clearInterval(intervalRef.current);
       // short delay so they see they lost the last life before switching to recap
       setTimeout(() => {
          setPhase('recap');
       }, 500);
    }
  }, [lives, phase]);

  // ── Step 4: Finish ──────────────────────────────────────────────────
  function handleFinish() {
    const score = Math.round((correctCount / Math.max(questions.length, 1)) * 100);
    setPhase('done');
    onComplete(score);
  }

  // ── Render ──────────────────────────────────────────────────────────
  if (phase === 'loading') return <LoadingScreen />;

  if (phase === 'recap' || phase === 'done') return (
    <RecapCard
      wrongQuestions={wrongQuestions}
      correctCount={correctCount}
      total={questions.length}
      xp={xp}
      onFinish={handleFinish}
    />
  );

  if (!currentMob) return null;

  return (
    <div className="td-game">
      {/* HUD */}
      <div className="td-hud">
        <div className="td-lives">{Array.from({length:3}).map((_,i) =>
          <span key={i} className={`td-heart ${i < lives ? 'alive' : 'lost'}`}>♥</span>
        )}</div>
        <div className="td-progress">{currentMobIndex + 1} / {questions.length}</div>
        <div className="td-xp">+{xp} XP</div>
      </div>

      {/* Background Gamified Scene */}
      <div className="absolute top-10 left-[0%] text-6xl opacity-40 cloud-anim fast">☁️</div>
      <div className="absolute top-5 left-[0%] text-7xl opacity-40 cloud-anim slow">☁️</div>
      <div className="absolute top-[20%] left-[0%] text-5xl opacity-40 cloud-anim" style={{ animationDelay: '-30s'}}>☁️</div>
      <div className="absolute top-[30%] left-[5%] text-5xl opacity-40 animate-pulse">☀️</div>

      <div className="absolute bottom-[40%] left-[20%] text-4xl sway-anim">🌲</div>
      <div className="absolute bottom-[42%] left-[50%] text-5xl sway-anim delay">🌲</div>
      <div className="absolute bottom-[40%] right-[10%] text-4xl sway-anim">🌳</div>

      {/* Path + Mobs */}
      <div className="td-arena">
        <div className="td-path">
          {/* Laser Beams */}
          {feedback === 'correct' && (
            <div className="laser-beam correct-laser" style={{ left: '0', right: `${100 - (100 - mobPosition)}%` }} />
          )}
          {feedback === 'wrong' && lives > 0 && mobPosition < 100 && (
            <div className="laser-beam wrong-laser" style={{ right: '0', left: `${100 - mobPosition}%` }} />
          )}
          
          {/* Main Mob */}
          <div
            className={`td-mob ${feedback === 'correct' ? 'exploding' : ''}`}
            style={{ left: `${100 - mobPosition}%`, zIndex: 100 }}
          >
            <div className="td-question-bubble">{currentMob.question}</div>
            <div className="td-mob-sprite">{currentMob.monsterSprite}</div>
          </div>
          
          {/* Trailing Mobs */}
          {questions.slice(currentMobIndex + 1, currentMobIndex + 4).map((mob, idx) => (
            <div
              key={mob.id}
              className="td-mob"
              style={{
                left: `${100 - mobPosition + (idx + 1) * 35}%`,
                opacity: 1 - (idx * 0.3),
                transform: `scale(${1 - (idx * 0.15)})`,
                zIndex: 90 - idx
              }}
            >
              <div className="td-mob-sprite grayscale opacity-50 blur-[2px]">{mob.monsterSprite}</div>
            </div>
          ))}
        </div>
        <div className="td-castle-wrapper">
          <CastleSprite />
        </div>
      </div>

      {/* Answer buttons */}
      <div className="td-answers">
        {currentMob.allOptions.map(option => (
          <button
            key={option}
            className={`td-answer-btn
              ${selectedOption === option && feedback === 'correct' ? 'correct' : ''}
              ${selectedOption === option && feedback === 'wrong' ? 'wrong' : ''}
              ${feedback === 'wrong' && option === currentMob.correct ? 'reveal' : ''}
            `}
            onClick={() => handleAnswer(option)}
            disabled={!!feedback}
          >
            {option}
          </button>
        ))}
      </div>

      {/* Explanation on wrong */}
      {feedback === 'wrong' && lives > 0 && mobPosition < 100 && (
        <div className="td-explanation">
          Correct: <strong>{currentMob.correct}</strong> — {currentMob.explanation}
        </div>
      )}
      {feedback === 'wrong' && (mobPosition >= 100 || lives <= 0) && (
        <div className="td-explanation border-red-500">
          Mob reached the base! The answer was <strong>{currentMob.correct}</strong> - {currentMob.explanation}
        </div>
      )}
    </div>
  );
}

// ── Helpers ─────────────────────────────────────────────────────────────
function shuffle<T>(arr: T[]): T[] {
  return [...arr].sort(() => Math.random() - 0.5);
}

function buildGeminiPrompt(topic: string, grade: number): string {
  return `You are a question generator for a gamified school learning app.
Generate exactly 10 flashcard question-answer pairs for the topic: "${topic}" for Grade ${grade} students.
Rules: Questions must test understanding. Distractors must be plausible mistakes. Explanations teach WHY in one sentence. Mix difficulty (3 easy, 4 medium, 3 hard).
Return ONLY valid JSON:
{"topic":"${topic}","grade":${grade},"questions":[{"id":1,"question":"...","correct":"...","distractors":["...","...","..."],"explanation":"...","difficulty":"easy"}]}`;
}
