import React from 'react';
import { GameQuestion } from './TowerDefenceGame';

interface RecapCardProps {
  wrongQuestions: GameQuestion[];
  correctCount: number;
  total: number;
  xp: number;
  onFinish: () => void;
}

export default function RecapCard({ wrongQuestions, correctCount, total, xp, onFinish }: RecapCardProps) {
  const percentage = Math.round((correctCount / Math.max(total, 1)) * 100);
  
  return (
    <div className="min-h-screen bg-sky-100 text-slate-800 p-8 flex flex-col items-center font-sans relative overflow-x-hidden">
      <div className="absolute top-10 right-10 text-6xl opacity-30">☁️</div>
      <div className="absolute top-40 left-10 text-5xl opacity-40">✨</div>
      <div className="absolute bottom-20 right-20 text-5xl opacity-50">🌟</div>

      <div className="max-w-2xl w-full z-10">
        <div className="text-center mb-10">
          <div className="text-7xl mb-4 drop-shadow-md">{percentage === 100 ? '🏆' : '🎉'}</div>
          <h1 className="text-5xl font-black mb-4 text-sky-700">Wave Complete!</h1>
          
          <div className="flex justify-center items-center gap-4 text-2xl font-bold mt-6">
             <div className="bg-sky-200 text-sky-800 px-6 py-3 rounded-2xl border-4 border-sky-300 shadow-sm">
               {correctCount} / {total} Correct
             </div>
             <div className="bg-green-100 text-green-600 px-6 py-3 rounded-2xl border-4 border-green-300 shadow-sm">
               Score: {percentage}%
             </div>
             <div className="bg-amber-100 text-amber-500 px-6 py-3 rounded-2xl border-4 border-amber-300 shadow-sm">
               +{xp} XP
             </div>
          </div>
        </div>

        {wrongQuestions.length > 0 ? (
          <div className="bg-white rounded-3xl overflow-hidden shadow-[0_10px_40px_-10px_rgba(0,0,0,0.15)] border-4 border-slate-200">
            <div className="bg-rose-100 text-rose-600 font-bold py-4 px-6 border-b-4 border-slate-200 text-xl flex items-center justify-between">
              <span>Needs Review</span>
              <span className="bg-rose-200 text-rose-700 px-3 py-1 rounded-xl text-lg">{wrongQuestions.length}</span>
            </div>
            <div className="divide-y-4 divide-slate-100 max-h-[50vh] overflow-y-auto">
              {wrongQuestions.map((q, i) => (
                <div key={q.id + '-' + i} className="p-6 bg-slate-50">
                  <div className="text-xl font-bold mb-4 text-slate-700">{q.question}</div>
                  
                  <div className="flex flex-col gap-2 mb-4 text-base">
                    <div className="flex items-center gap-3">
                       <div className="text-green-500 font-extrabold text-2xl bg-green-100 w-8 h-8 rounded-full flex items-center justify-center shrink-0">✓</div>
                       <span className="bg-green-100 text-green-800 px-4 py-2 rounded-xl border-2 border-green-200 w-full font-bold">
                         {q.correct}
                       </span>
                    </div>
                  </div>
                  
                  <div className="text-slate-500 text-base font-semibold italic border-l-4 border-sky-300 pl-4 py-1 bg-white rounded-r-xl border border-l-0 border-slate-200">
                    <span className="text-sky-500 not-italic mr-2">💡</span>
                    {q.explanation}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="bg-white rounded-3xl p-12 text-center shadow-[0_10px_40px_-10px_rgba(0,0,0,0.15)] border-4 border-green-300">
             <div className="text-8xl mb-6">👑</div>
             <h2 className="text-3xl font-black text-green-500 mb-2">Perfect Wave!</h2>
             <p className="text-slate-500 font-bold text-xl">You destroyed every mob without missing.</p>
          </div>
        )}

        <button 
          onClick={onFinish}
          className="w-full mt-10 bg-sky-500 hover:bg-sky-400 text-white font-black py-5 px-8 rounded-2xl shadow-[0_6px_0_0_#0284c7] hover:shadow-[0_4px_0_0_#0284c7] hover:translate-y-[2px] active:shadow-none active:translate-y-[6px] transition-all text-2xl"
        >
          Continue Adventure
        </button>
      </div>
    </div>
  );
}
