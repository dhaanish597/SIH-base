import React from 'react';

export default function LoadingScreen() {
  return (
    <div className="flex bg-sky-100 text-slate-800 flex-col items-center justify-center min-h-screen relative overflow-hidden font-sans">
      <div className="absolute top-10 left-10 text-6xl opacity-30 animate-pulse">☁️</div>
      <div className="absolute bottom-20 right-20 text-6xl opacity-30 animate-pulse" style={{ animationDelay: '1s'}}>☁️</div>
      
      <div className="text-8xl mb-8 animate-bounce drop-shadow-lg">👾</div>
      <h2 className="text-4xl font-black mb-4 text-sky-600">Generating Wave...</h2>
      <p className="text-slate-500 font-bold text-xl">Summoning mobs using Gemini</p>
      
      <div className="mt-10 w-72 h-4 bg-sky-200 rounded-full overflow-hidden border-2 border-sky-300">
        <div className="h-full bg-green-400 rounded-full animate-[pulse_2s_ease-in-out_infinite]" style={{ width: '100%' }}></div>
      </div>
    </div>
  );
}
