import React from 'react';

export default function CastleSprite() {
  return (
    <svg viewBox="0 0 400 300" className="w-[180px] md:w-[240px] h-auto drop-shadow-2xl" xmlns="http://www.w3.org/2000/svg">
      {/* Background shadow/outline layer */}
      <defs>
        <linearGradient id="doorGradient" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#8b5a2b" />
          <stop offset="50%" stopColor="#a0522d" />
          <stop offset="100%" stopColor="#8b5a2b" />
        </linearGradient>
        <pattern id="brick" width="40" height="20" patternUnits="userSpaceOnUse">
          <rect width="40" height="20" fill="#b0b3b8" />
          <path d="M0,10 H40 M20,0 V10 M0,10 V20 M40,10 V20" stroke="#8a8d91" strokeWidth="2" />
        </pattern>
        <pattern id="darkBrick" width="40" height="20" patternUnits="userSpaceOnUse">
          <rect width="40" height="20" fill="#9ca3af" />
          <path d="M0,10 H40 M20,0 V10 M0,10 V20 M40,10 V20" stroke="#6b7280" strokeWidth="2" />
        </pattern>
      </defs>

      {/* Base shadows */}
      <rect x="30" y="270" width="340" height="20" fill="#374151" rx="5" />

      {/* Left Tower */}
      <rect x="40" y="120" width="60" height="160" fill="url(#darkBrick)" stroke="#4b5563" strokeWidth="4" />
      <polygon points="35,120 105,120 70,60" fill="#6b7280" stroke="#4b5563" strokeWidth="4" />
      <path d="M70,60 L70,30 L95,40 L70,50" fill="#3b82f6" stroke="#1e3a8a" strokeWidth="2" />
      <rect x="65" y="160" width="10" height="30" rx="5" fill="#1f2937" />

      {/* Far Right Tower */}
      <rect x="310" y="140" width="60" height="140" fill="url(#darkBrick)" stroke="#4b5563" strokeWidth="4" />
      <polygon points="310,140 310,120 325,120 325,140 340,140 340,120 355,120 355,140 370,140 370,120 370,140" fill="url(#brick)" stroke="#4b5563" strokeWidth="4" />
      <rect x="335" y="180" width="10" height="30" rx="5" fill="#1f2937" />

      {/* Main Base */}
      <rect x="90" y="160" width="230" height="120" fill="url(#brick)" stroke="#4b5563" strokeWidth="4" />
      <path d="M90,160 L110,160 L110,140 L130,140 L130,160 L150,160 L150,140 L170,140 L170,160 L190,160 L190,140 L210,140 L210,160 L230,160 L230,140 L250,140 L250,160 L270,160 L270,140 L290,140 L290,160 L310,160 L310,140 L320,140 L320,160" fill="url(#brick)" stroke="#4b5563" strokeWidth="4" />
      
      {/* Central Tower */}
      <rect x="130" y="80" width="90" height="80" fill="url(#brick)" stroke="#4b5563" strokeWidth="4" />
      <path d="M125,80 L145,80 L145,60 L165,60 L165,80 L185,80 L185,60 L205,60 L205,80 L225,80 L225,60 L225,80" fill="url(#brick)" stroke="#4b5563" strokeWidth="4" />
      <rect x="165" y="100" width="20" height="40" rx="10" fill="#1f2937" />

      {/* Right Inner Tower */}
      <rect x="250" y="110" width="50" height="50" fill="url(#darkBrick)" stroke="#4b5563" strokeWidth="4" />
      <path d="M245,110 L260,110 L260,95 L275,95 L275,110 L290,110 L290,95 L305,95 L305,110" fill="url(#brick)" stroke="#4b5563" strokeWidth="4" />
      <rect x="270" y="125" width="10" height="20" rx="5" fill="#1f2937" />

      {/* Left Inner Tower */}
      <rect x="80" y="110" width="50" height="50" fill="url(#darkBrick)" stroke="#4b5563" strokeWidth="4" />
      <path d="M75,110 L90,110 L90,95 L105,95 L105,110 L120,110 L120,95 L135,95 L135,110" fill="url(#brick)" stroke="#4b5563" strokeWidth="4" />
      <rect x="100" y="125" width="10" height="20" rx="5" fill="#1f2937" />

      {/* Cannons (pointing right) */}
      <g id="cannons">
        {/* Top central cannon */}
        <path d="M160,50 L200,45 L200,55 L160,60" fill="#475569" stroke="#1e293b" strokeWidth="3" />
        <circle cx="180" cy="55" r="10" fill="#b45309" stroke="#78350f" strokeWidth="2" />
        <rect x="195" y="42" width="15" height="15" rx="2" fill="#475569" stroke="#1e293b" strokeWidth="2" />
        
        {/* Top left inner cannon */}
        <path d="M95,85 L135,80 L135,90 L95,95" fill="#475569" stroke="#1e293b" strokeWidth="3" />
        <circle cx="115" cy="90" r="10" fill="#b45309" stroke="#78350f" strokeWidth="2" />
        <rect x="130" y="77" width="15" height="15" rx="2" fill="#475569" stroke="#1e293b" strokeWidth="2" />
        
        {/* Top right inner cannon */}
        <path d="M260,85 L300,80 L300,90 L260,95" fill="#475569" stroke="#1e293b" strokeWidth="3" />
        <circle cx="280" cy="90" r="10" fill="#b45309" stroke="#78350f" strokeWidth="2" />
        <rect x="295" y="77" width="15" height="15" rx="2" fill="#475569" stroke="#1e293b" strokeWidth="2" />

        {/* Far right tower cannon */}
        <path d="M325,110 L365,105 L365,115 L325,120" fill="#475569" stroke="#1e293b" strokeWidth="3" />
        <circle cx="345" cy="115" r="10" fill="#b45309" stroke="#78350f" strokeWidth="2" />
        <rect x="360" y="102" width="15" height="15" rx="2" fill="#475569" stroke="#1e293b" strokeWidth="2" />
      </g>

      {/* Main Door */}
      <path d="M170,280 L170,220 A 35,35 0 0,1 240,220 L240,280 Z" fill="url(#doorGradient)" stroke="#4b5563" strokeWidth="6" />
      <line x1="205" y1="220" x2="205" y2="280" stroke="#4b5563" strokeWidth="3" />
      <circle cx="195" cy="250" r="4" fill="#d1d5db" />
      <circle cx="215" cy="250" r="4" fill="#d1d5db" />
      
      {/* Wooden Arch over door */}
      <path d="M165,220 A 40,40 0 0,1 245,220" fill="none" stroke="#6b7280" strokeWidth="8" />

      {/* Banners */}
      {/* Middle tower banner left */}
      <path d="M140,80 L155,80 L155,115 L147.5,105 L140,115 Z" fill="#0284c7" stroke="#fbbf24" strokeWidth="2" />
      {/* Middle tower banner right */}
      <path d="M195,80 L210,80 L210,115 L202.5,105 L195,115 Z" fill="#0284c7" stroke="#fbbf24" strokeWidth="2" />
      {/* Star inside the banner */}
      <circle cx="202.5" cy="95" r="4" fill="#fcd34d" />
      
      {/* Big lower banner left */}
      <g transform="translate(110, 180)">
        <path d="M0,0 L35,0 L35,60 L17.5,75 L0,60 Z" fill="#0284c7" stroke="#fbbf24" strokeWidth="3" />
        <path d="M17.5,0 L35,0 L35,60 L17.5,75 Z" fill="#fbbf24" />
        <text x="17.5" y="45" fontFamily="serif" fontSize="24" fontWeight="bold" fill="#fff" textAnchor="middle">A</text>
      </g>

      {/* Big lower banner right */}
      <g transform="translate(260, 180)">
        <path d="M0,0 L35,0 L35,60 L17.5,75 L0,60 Z" fill="#0284c7" stroke="#fbbf24" strokeWidth="3" />
        <path d="M17.5,0 L35,0 L35,60 L17.5,75 Z" fill="#f97316" />
        <text x="17.5" y="45" fontFamily="serif" fontSize="24" fontWeight="bold" fill="#fff" textAnchor="middle">A</text>
      </g>
    </svg>
  );
}
