import React, { useState } from 'react';
import { GameScreen } from './components/GameScreen';
import { levels } from './lib/levels';

export default function App() {
  const [currentLevelIndex, setCurrentLevelIndex] = useState(0);

  const handleNextLevel = () => {
    if (currentLevelIndex < levels.length - 1) {
      setCurrentLevelIndex(prev => prev + 1);
    } else {
      // Game Complete
      alert("You beat all the levels! Restarting game.");
      setCurrentLevelIndex(0);
    }
  };

  return (
    <div className="h-screen w-full bg-slate-950 font-sans">
      <GameScreen 
        key={levels[currentLevelIndex].id} // Force remount on level change
        level={levels[currentLevelIndex]} 
        onNextLevel={handleNextLevel} 
      />
    </div>
  );
}
