export type Direction = 'N' | 'E' | 'S' | 'W';

export type CommandType = 'FORWARD' | 'LEFT' | 'RIGHT' | 'REPEAT' | 'IF_OBSTACLE' | 'FUNCTION';

export interface CommandNode {
  id: string; // Unique identifier for highlighting
  type: CommandType;
  count?: number; // For REPEAT
  children?: CommandNode[]; // For REPEAT, IF_OBSTACLE, FUNCTION
}

export type GridCell = 'E' | 'W' | 'S' | 'X'; // Empty, Wall, Start, eXit

export interface Level {
  id: number;
  title: string;
  description: string;
  grid: GridCell[][];
  startPos: { x: number; y: number };
  startDir: Direction;
  availableCommands: CommandType[];
  maxBlocks: number;
}

export type GameStatus = 'idle' | 'running' | 'success' | 'crash-wall' | 'wrong-direction' | 'infinite-loop' | 'incomplete';
