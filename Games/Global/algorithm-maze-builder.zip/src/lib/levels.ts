import { Level } from '../types/game';

const E = 'E'; // Empty
const W = 'W'; // Wall
const S = 'S'; // Start
const X = 'X'; // Exit

export const levels: Level[] = [
  {
    id: 1,
    title: "Level 1: Straight Ahead",
    description: "Move forward 4 times to reach the exit.",
    grid: [
      [W, W, W, W, W, W, W],
      [W, S, E, E, E, X, W],
      [W, W, W, W, W, W, W],
    ],
    startPos: { x: 1, y: 1 },
    startDir: 'E',
    availableCommands: ['FORWARD'],
    maxBlocks: 4,
  },
  {
    id: 2,
    title: "Level 2: The Turn",
    description: "Facing direction matters.",
    grid: [
      [W, W, W, W, W],
      [W, S, E, W, W],
      [W, W, E, W, W],
      [W, W, X, W, W],
      [W, W, W, W, W],
    ],
    startPos: { x: 1, y: 1 },
    startDir: 'E',
    availableCommands: ['FORWARD', 'LEFT', 'RIGHT'],
    maxBlocks: 4,
  },
  {
    id: 3,
    title: "Level 3: Zig Zag",
    description: "Order of moves and turns is important.",
    grid: [
      [W, W, W, W, W, W],
      [W, S, W, W, W, W],
      [W, E, E, W, W, W],
      [W, W, E, E, W, W],
      [W, W, W, X, W, W],
      [W, W, W, W, W, W]
    ],
    startPos: { x: 1, y: 1 },
    startDir: 'S',
    availableCommands: ['FORWARD', 'LEFT', 'RIGHT'],
    maxBlocks: 8,
  },
  {
    id: 4,
    title: "Level 4: The Long Hallway",
    description: "Use REPEAT to reduce the number of blocks.",
    grid: [
      [W, W, W, W, W, W, W, W, W],
      [W, S, E, E, E, E, E, X, W],
      [W, W, W, W, W, W, W, W, W],
    ],
    startPos: { x: 1, y: 1 },
    startDir: 'E',
    availableCommands: ['FORWARD', 'REPEAT'],
    maxBlocks: 3,
  },
  {
    id: 5,
    title: "Level 5: Spiral",
    description: "Nested loops can be powerful.",
    grid: [
      [W, W, W, W, W, W, W],
      [W, S, E, E, E, E, W],
      [W, W, W, W, W, E, W],
      [W, E, E, E, W, E, W],
      [W, X, W, E, W, E, W],
      [W, W, W, E, E, E, W],
      [W, W, W, W, W, W, W]
    ],
    startPos: { x: 1, y: 1 },
    startDir: 'E',
    availableCommands: ['FORWARD', 'LEFT', 'RIGHT', 'REPEAT'],
    maxBlocks: 8,
  },
  {
    id: 6,
    title: "Level 6: Fork in the Road",
    description: "Use IF OBSTACLE to navigate around blockages.",
    grid: [
      [W, W, W, W, W, W, W, W, W],
      [W, S, W, E, W, E, W, X, W],
      [W, E, W, E, W, E, W, E, W],
      [W, E, E, E, E, E, E, E, W],
      [W, W, W, W, W, W, W, W, W],
    ],
    startPos: { x: 1, y: 1 },
    startDir: 'S',
    availableCommands: ['FORWARD', 'LEFT', 'RIGHT', 'REPEAT', 'IF_OBSTACLE'],
    maxBlocks: 10,
  }
];
