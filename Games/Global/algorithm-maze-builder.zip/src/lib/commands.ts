import { CommandType } from '../types/game';

export const COMMAND_CONFIG: Record<CommandType, { name: string; color: string; icon: string }> = {
  FORWARD: { name: 'MOVE FWD', color: 'bg-amber-400 text-slate-950 font-black italic', icon: '↗️' },
  LEFT: { name: 'TURN LEFT', color: 'bg-blue-400 text-slate-950 font-black italic', icon: '↩️' },
  RIGHT: { name: 'TURN RIGHT', color: 'bg-blue-400 text-slate-950 font-black italic', icon: '↪️' },
  REPEAT: { name: 'REPEAT', color: 'bg-pink-500 text-white font-black italic', icon: '🔁' },
  IF_OBSTACLE: { name: 'IF OBSTACLE', color: 'bg-emerald-400 text-slate-950 font-black italic', icon: '🔀' },
  FUNCTION: { name: 'FUNCTION', color: 'bg-violet-400 text-slate-950 font-black italic', icon: '📦' },
};
