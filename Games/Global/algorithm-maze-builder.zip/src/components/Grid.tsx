import React from 'react';
import { motion } from 'motion/react';
import { GridCell, RobotState } from '../types/game';
import { TracePoint } from '../hooks/useGameEngine';
import { cn } from '../lib/utils';
import { ArrowUp, ArrowRight, ArrowDown, ArrowLeft } from 'lucide-react';

interface GridProps {
  grid: GridCell[][];
  robotState: RobotState;
  pathTrace: TracePoint[];
  status: string;
}

export function Grid({ grid, robotState, pathTrace, status }: GridProps) {
  const getRotation = (dir: string) => {
    switch (dir) {
      case 'N': return 0;
      case 'E': return 90;
      case 'S': return 180;
      case 'W': return -90; // Or 270, using -90 avoids weird spin
      default: return 0;
    }
  };

  return (
    <div className="relative inline-block bg-slate-900 border border-slate-800 rounded-2xl p-3 shadow-2xl">
      <div 
        className="grid gap-1.5" 
        style={{ 
          gridTemplateColumns: `repeat(${grid[0].length}, minmax(0, 1fr))` 
        }}
      >
        {grid.map((row, y) => (
          row.map((cell, x) => {
            const isPath = pathTrace.some(p => p.x === x && p.y === y);
            return (
              <div 
                key={`${x}-${y}`}
                className={cn(
                  "w-12 h-12 rounded-md transition-colors duration-300 relative",
                  cell === 'W' && "bg-slate-950",
                  cell === 'E' && "bg-slate-800/40",
                  cell === 'S' && "bg-slate-800/40 border-2 border-cyan-500/20",
                  cell === 'X' && "bg-slate-800/40 flex items-center justify-center relative",
                  isPath && cell === 'E' && "bg-slate-700/40",
                  status === 'crash-wall' && robotState.x === x && robotState.y === y && "bg-red-500/20 animate-pulse border-red-500/50"
                )}
              >
                {cell === 'X' && (
                  <>
                    <div className="absolute inset-0 bg-violet-600/30 blur-xl"></div>
                    <div className="w-8 h-8 border-2 border-violet-500 rounded-full flex items-center justify-center relative z-10">
                      <div className="w-3 h-3 bg-violet-400 rounded-sm rotate-45 animate-pulse"></div>
                    </div>
                  </>
                )}
              </div>
            );
          })
        ))}
      </div>

      {/* Robot Overlay */}
      <motion.div
        className="absolute top-3 left-3 w-12 h-12 flex items-center justify-center pointer-events-none z-10"
        initial={false}
        animate={{
          x: robotState.x * 54, // 48px width + 6px gap = 54px
          y: robotState.y * 54,
        }}
        transition={{ type: 'spring', stiffness: 200, damping: 20 }}
      >
        <motion.div
          animate={{ rotate: getRotation(robotState.dir) }}
          transition={{ type: 'spring', stiffness: 200, damping: 20 }}
          className={cn(
            "w-10 h-10 rounded-lg shadow-[0_0_25px_#22d3ee] flex items-center justify-center flex-col shadow-cyan-400/50",
            status === 'crash-wall' ? "bg-red-500 shadow-red-500/80" : "bg-cyan-400",
            status === 'success' && "bg-violet-400 shadow-[0_0_25px_rgba(167,139,250,0.8)]"
          )}
        >
          {/* Bento eyes */}
          <div className="w-6 h-4 border-2 border-slate-900 flex justify-around items-center rounded bg-cyan-500">
            <div className="w-1.5 h-1.5 bg-slate-900 rounded-full"></div>
            <div className="w-1.5 h-1.5 bg-slate-900 rounded-full"></div>
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
}
