import React from 'react';
import { CommandNode } from '../types/game';
import { CommandCard } from './CommandCard';

interface CommandStripProps {
  commands: CommandNode[];
  activeCommandId: string | null;
  onRemove: (id: string) => void;
  onUpdateRepeatCount: (id: string, delta: number) => void;
  renderAddZone: (parentId: string | null) => React.ReactNode;
}

export function CommandStrip({ 
  commands, 
  activeCommandId, 
  onRemove, 
  onUpdateRepeatCount,
  renderAddZone
}: CommandStripProps) {
  
  const renderNode = (node: CommandNode) => {
    if (node.type === 'REPEAT') {
      return (
        <CommandCard 
          key={node.id} 
          type={node.type} 
          isActive={activeCommandId === node.id}
          onRemove={() => onRemove(node.id)}
          className="flex-col w-full"
        >
          <div className="flex items-center gap-2 bg-black/10 p-1.5 rounded text-[10px] mb-1 text-inherit">
            <span className="uppercase font-bold tracking-wider">Times:</span>
            <button 
              className="bg-black/20 hover:bg-black/40 px-2 rounded-sm" 
              onClick={() => onUpdateRepeatCount(node.id, -1)}
            >-</button>
            <span className="font-bold w-4 text-center">{node.count || 2}</span>
            <button 
              className="bg-black/20 hover:bg-black/40 px-2 rounded-sm"
              onClick={() => onUpdateRepeatCount(node.id, 1)}
            >+</button>
          </div>
          
          <div className="pl-3 ml-2 border-l-2 border-white/30 min-h-[50px] flex flex-col gap-2 rounded-r bg-black/10 py-3 pr-2">
            {node.children?.map(renderNode)}
            <div className="w-full flex items-center justify-center">
              {renderAddZone(node.id)}
            </div>
          </div>
        </CommandCard>
      );
    }
    
    if (node.type === 'IF_OBSTACLE') {
      return (
        <CommandCard 
          key={node.id} 
          type={node.type} 
          isActive={activeCommandId === node.id}
          onRemove={() => onRemove(node.id)}
          className="flex-col w-full"
        >
          <div className="pl-3 ml-2 border-l-2 border-slate-900/40 min-h-[50px] flex flex-col gap-2 rounded-r bg-black/10 py-3 pr-2">
            {node.children?.map(renderNode)}
            <div className="w-full flex items-center justify-center">
              {renderAddZone(node.id)}
            </div>
          </div>
        </CommandCard>
      );
    }

    return (
      <CommandCard 
        key={node.id} 
        type={node.type} 
        isActive={activeCommandId === node.id}
        onRemove={() => onRemove(node.id)}
      />
    );
  };

  return (
    <div className="flex flex-col gap-2 w-full pb-8">
      {commands.map(renderNode)}
      
      <div className="h-[42px] border-2 border-slate-800 rounded-md border-dashed flex items-center justify-center bg-slate-950/30">
        {renderAddZone(null)}
      </div>
    </div>
  );
}
