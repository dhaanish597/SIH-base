import React, { useState, useEffect } from 'react';
import { CommandNode, CommandType, Level } from '../types/game';
import { useGameEngine } from '../hooks/useGameEngine';
import { Grid } from './Grid';
import { CommandStrip } from './CommandStrip';
import { COMMAND_CONFIG } from '../lib/commands';
import { PlusCircle, Play, RotateCcw, AlertTriangle, CheckCircle2, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

import { cn } from '../lib/utils';

interface GameScreenProps {
  level: Level;
  onNextLevel: () => void;
}

export function GameScreen({ level, onNextLevel }: GameScreenProps) {
  const [commands, setCommands] = useState<CommandNode[]>([]);
  const { status, robotState, activeCommandId, pathTrace, runProgram, reset, errorMessage } = useGameEngine(level);

  // When level changes, reset everything
  useEffect(() => {
    setCommands([]);
    reset();
  }, [level, reset]);

  const addCommand = (type: CommandType, parentId: string | null) => {
    const newNode: CommandNode = {
      id: Math.random().toString(36).substr(2, 9),
      type,
      ...((type === 'REPEAT' || type === 'IF_OBSTACLE') ? { children: [] } : {}),
      ...(type === 'REPEAT' ? { count: 2 } : {})
    };

    if (!parentId) {
      setCommands(prev => [...prev, newNode]);
      return;
    }

    const insertIntoTree = (nodes: CommandNode[]): CommandNode[] => {
      return nodes.map(node => {
        if (node.id === parentId && (node.type === 'REPEAT' || node.type === 'IF_OBSTACLE')) {
          return { ...node, children: [...(node.children || []), newNode] };
        }
        if (node.children) {
          return { ...node, children: insertIntoTree(node.children) };
        }
        return node;
      });
    };

    setCommands(prev => insertIntoTree(prev));
  };

  const removeCommand = (id: string) => {
    const removeFromTree = (nodes: CommandNode[]): CommandNode[] => {
      return nodes.filter(node => node.id !== id).map(node => ({
        ...node,
        ...(node.children ? { children: removeFromTree(node.children) } : {})
      }));
    };
    setCommands(prev => removeFromTree(prev));
  };

  const updateRepeatCount = (id: string, delta: number) => {
    const updateTree = (nodes: CommandNode[]): CommandNode[] => {
      return nodes.map(node => {
        if (node.id === id && node.type === 'REPEAT') {
          const newCount = Math.max(1, Math.min(20, (node.count || 2) + delta));
          return { ...node, count: newCount };
        }
        if (node.children) {
          return { ...node, children: updateTree(node.children) };
        }
        return node;
      });
    };
    setCommands(prev => updateTree(prev));
  };

  const countTotalBlocks = (nodes: CommandNode[]): number => {
    return nodes.reduce((acc, node) => acc + 1 + (node.children ? countTotalBlocks(node.children) : 0), 0);
  };
  
  const blocksUsed = countTotalBlocks(commands);
  const blocksRemaining = level.maxBlocks - blocksUsed;
  const isRunning = status === 'running';
  const isSuccess = status === 'success';

  const renderAddZone = (parentId: string | null) => {
    return (
      <div className="relative group shrink-0 flex items-center justify-center w-full min-h-[32px]">
        {blocksRemaining <= 0 ? (
           <span className="text-[10px] text-slate-700 font-bold uppercase tracking-widest">Limit Reached</span>
        ) : (
          <div className="flex items-center justify-center gap-2 w-full">
            <span className="text-[10px] text-slate-600 font-bold uppercase tracking-widest group-hover:hidden transition-opacity">Drop Command</span>
            {/* Inline tool list that appears horizontally */}
            <div className="hidden group-hover:flex focus-within:flex flex-wrap items-center justify-center gap-2 bg-slate-900/40 p-2 rounded-xl justify-center transition-opacity w-full border border-slate-800/50">
              {level.availableCommands.map(cmd => {
                const config = COMMAND_CONFIG[cmd];
                return (
                  <button
                    key={cmd}
                    title={config.name}
                    onClick={() => addCommand(cmd, parentId)}
                    className={cn("px-2 py-1.5 rounded flex items-center justify-center text-sm transition-colors opacity-90 hover:opacity-100 hover:scale-105 active:scale-95", config.color)}
                  >
                    {config.name}
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="flex h-full w-full bg-slate-950 text-slate-100 overflow-hidden font-sans selection:bg-cyan-500/30">
      {/* Sidebar Command Panel */}
      <aside className="w-[340px] shrink-0 h-full bg-slate-900 border-r border-slate-800 flex flex-col p-6 space-y-6 z-20">
        <div className="space-y-1">
          <h1 className="text-xs font-bold tracking-widest text-cyan-500 uppercase">Level 0{level.id}</h1>
          <h2 className="text-xl font-medium">{level.title}</h2>
          <p className="text-sm text-slate-400">{level.description}</p>
        </div>

        <div className="flex items-center gap-4">
          <div className="bg-slate-800/50 px-3 py-1.5 rounded-md text-sm font-medium border border-slate-700/50">
            Blocks: <span className={blocksRemaining < 0 ? "text-red-400" : "text-cyan-400"}>{blocksUsed}</span> / {level.maxBlocks}
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3">
          <button
            onClick={() => runProgram(commands)}
            disabled={isRunning || commands.length === 0}
            className="w-full py-4 bg-emerald-500 hover:bg-emerald-400 text-emerald-950 font-black text-lg tracking-widest rounded-xl transition-all shadow-[0_0_30px_rgba(16,185,129,0.3)] disabled:opacity-50 disabled:shadow-none"
          >
            {isRunning ? 'RUNNING...' : 'RUN PROGRAM'}
          </button>
          
          <button
            onClick={reset}
            disabled={isRunning}
            className="w-full py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold tracking-widest rounded-xl transition-colors disabled:opacity-50 text-sm uppercase"
          >
            Reset Simulation
          </button>
        </div>

        {/* Program Strip / Queue */}
        <div className="flex-1 space-y-4 overflow-hidden flex flex-col pt-4 border-t border-slate-800">
          <div className="flex justify-between items-end">
             <h3 className="text-[10px] items-center gap-2 font-semibold text-slate-500 uppercase tracking-wider flex">
                Program Sequence 
                {blocksRemaining <= 0 && <span className="text-amber-500 font-black text-[9px] px-1 bg-amber-500/20 rounded">FULL</span>}
             </h3>
          </div>
          <div className="flex-1 overflow-y-auto custom-scrollbar -mx-2 px-2 pb-2">
            <CommandStrip 
              commands={commands}
              activeCommandId={activeCommandId}
              onRemove={removeCommand}
              onUpdateRepeatCount={updateRepeatCount}
              renderAddZone={renderAddZone}
            />
          </div>
        </div>
      </aside>

      {/* Main Arena Area */}
      <main className="flex-1 h-full relative flex flex-col items-center justify-center p-12">
        {/* Grid Background Decoration */}
        <div className="absolute inset-0 opacity-10 pointer-events-none" style={{ backgroundImage: 'radial-gradient(#334155 1px, transparent 1px)', backgroundSize: '40px 40px' }}></div>
        
        <div className="relative z-10 w-full h-full flex flex-col items-center justify-center">
          <Grid 
            grid={level.grid} 
            robotState={robotState} 
            pathTrace={pathTrace}
            status={status}
          />

          {/* Footer Status */}
          <div className="mt-8 flex space-x-12 items-center bg-slate-900/80 px-6 py-3 rounded-full border border-slate-800 backdrop-blur-sm shadow-xl">
            <div className="flex flex-col">
              <span className="text-[10px] text-slate-500 uppercase font-bold tracking-tighter">Status</span>
              <span className="text-xs text-cyan-400 font-mono tracking-wide">{status === 'idle' ? 'IDLE | WAITING' : status.toUpperCase()}</span>
            </div>
            <div className="h-6 w-[1px] bg-slate-800"></div>
            <div className="flex flex-col w-32">
              <span className="text-[10px] text-slate-500 uppercase font-bold tracking-tighter">Blocks Remaining</span>
              <div className="w-full h-1.5 bg-slate-800 rounded-full mt-1 overflow-hidden">
                <div className="h-full bg-cyan-500 rounded-full transition-all duration-300" style={{ width: `${Math.max(0, (blocksRemaining / level.maxBlocks)) * 100}%` }}></div>
              </div>
            </div>
          </div>
        </div>

        <AnimatePresence>
          {errorMessage && !isSuccess && (
            <motion.div 
              initial={{ opacity: 0, y: 10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="absolute top-6 max-w-md bg-red-900/90 border border-red-500/50 text-red-100 p-4 rounded-xl shadow-2xl flex gap-3 items-start z-50 backdrop-blur-md"
            >
              <AlertTriangle className="shrink-0 text-red-400 mt-0.5" />
              <div className="text-sm font-medium leading-relaxed">{errorMessage}</div>
            </motion.div>
          )}

          {isSuccess && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              className="absolute z-50 bg-slate-800/90 backdrop-blur-xl border border-violet-500 p-8 rounded-2xl shadow-[0_0_50px_rgba(139,92,246,0.2)] max-w-sm w-full mx-auto"
            >
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 bg-violet-500/20 rounded-full flex items-center justify-center mb-4">
                  <CheckCircle2 className="text-violet-400 w-10 h-10" />
                </div>
                <h2 className="text-2xl font-black text-white mb-2 uppercase tracking-wide">Algorithm Complete</h2>
                <p className="text-slate-300 text-sm mb-6">Extraction point reached successfully.</p>
                
                <button 
                  onClick={onNextLevel}
                  className="w-full py-4 bg-violet-600 hover:bg-violet-500 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition-colors focus:ring-4 focus:ring-violet-500/50 outline-none uppercase tracking-widest text-sm shadow-lg shadow-violet-600/30"
                >
                  Next Level <ChevronRight size={18} />
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
