import React from 'react';
import { COMMAND_CONFIG } from '../lib/commands';
import { CommandType } from '../types/game';
import { cn } from '../lib/utils';
import { Trash2 } from 'lucide-react';

interface CommandCardProps {
  type: CommandType;
  isActive?: boolean;
  onRemove?: () => void;
  className?: string;
  children?: React.ReactNode;
}

export function CommandCard({ type, isActive, onRemove, className, children }: CommandCardProps) {
  const config = COMMAND_CONFIG[type];

  return (
    <div className={cn(
      "relative rounded-md p-3 flex flex-col gap-2 shadow-lg transition-all select-none w-full",
      config.color,
      isActive && "ring-4 ring-white brightness-110 z-10 scale-[1.02]",
      className
    )}>
      <div className="flex items-center gap-2">
        <span className="font-black italic text-xs uppercase opacity-80">{config.icon} | {config.name}</span>
        
        {onRemove && (
          <button 
            onClick={(e) => { e.stopPropagation(); onRemove(); }}
            className="ml-auto opacity-50 hover:opacity-100 transition-opacity"
          >
            ✕
          </button>
        )}
      </div>
      {children && (
        <div className="mt-1">
          {children}
        </div>
      )}
    </div>
  );
}
