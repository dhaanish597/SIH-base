import { useState, useCallback, useRef } from 'react';
import { CommandNode, Direction, GameStatus, Level, RobotState } from '../types/game';

export interface TracePoint {
  x: number;
  y: number;
}

export function useGameEngine(level: Level) {
  const [status, setStatus] = useState<GameStatus>('idle');
  const [robotState, setRobotState] = useState<RobotState>({
    x: level.startPos.x,
    y: level.startPos.y,
    dir: level.startDir
  });
  const [activeCommandId, setActiveCommandId] = useState<string | null>(null);
  const [pathTrace, setPathTrace] = useState<TracePoint[]>([{ x: level.startPos.x, y: level.startPos.y }]);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const runningRef = useRef(false);
  const timeoutRef = useRef<number | null>(null);

  const reset = useCallback(() => {
    runningRef.current = false;
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    
    setStatus('idle');
    setRobotState({
      x: level.startPos.x,
      y: level.startPos.y,
      dir: level.startDir
    });
    setActiveCommandId(null);
    setPathTrace([{ x: level.startPos.x, y: level.startPos.y }]);
    setErrorMessage(null);
  }, [level]);

  const executeCommandStep = async (
    commands: CommandNode[], 
    currentState: RobotState,
    currentTrace: TracePoint[],
    stepCountRef: { count: number }
  ): Promise<{ state: RobotState; newStatus: GameStatus; trace: TracePoint[] }> => {
    
    let state = { ...currentState };
    let trace = [...currentTrace];
    
    for (const cmd of commands) {
      if (!runningRef.current) return { state, newStatus: 'idle', trace };

      stepCountRef.count++;
      if (stepCountRef.count > 1000) {
        // Infinite loop catch just in case, but usually infinite loops are handled by a time limit
        // as requested: spinning forever caught after 3s. For now step limit is our proxy.
        setActiveCommandId(cmd.id);
        setErrorMessage("Infinite loop detected! The robot ran too many steps.");
        return { state, newStatus: 'infinite-loop', trace };
      }

      setActiveCommandId(cmd.id);
      
      // Wait for animation
      await new Promise(r => { timeoutRef.current = window.setTimeout(r, 600) });
      if (!runningRef.current) return { state, newStatus: 'idle', trace };

      if (cmd.type === 'FORWARD') {
        let nextX = state.x;
        let nextY = state.y;
        if (state.dir === 'N') nextY -= 1;
        if (state.dir === 'E') nextX += 1;
        if (state.dir === 'S') nextY += 1;
        if (state.dir === 'W') nextX -= 1;

        const cell = level.grid[nextY]?.[nextX];
        if (!cell || cell === 'W') {
          setErrorMessage("The robot walked into a wall. Try turning first!");
          return { state: { ...state, x: nextX, y: nextY }, newStatus: 'crash-wall', trace };
        }
        
        state.x = nextX;
        state.y = nextY;
        trace.push({ x: nextX, y: nextY });
        
        setRobotState({ ...state });
        setPathTrace([...trace]);
        
        if (cell === 'X') {
          // Reached exit! BUT we should only succeed if this is the intended end, or just succeeding is fine.
          // Let's delay success to the end of evaluating, or succeed immediately. 
          // Usually, reaching the exit is a success. Let's succeed immediately for simplicity.
          return { state, newStatus: 'success', trace };
        }
      } else if (cmd.type === 'LEFT') {
        const dirs: Direction[] = ['N', 'W', 'S', 'E']; // Left turns
        const currIdx = dirs.indexOf(state.dir);
        state.dir = dirs[(currIdx + 1) % 4];
        setRobotState({ ...state });
      } else if (cmd.type === 'RIGHT') {
        const dirs: Direction[] = ['N', 'E', 'S', 'W']; // Right turns
        const currIdx = dirs.indexOf(state.dir);
        state.dir = dirs[(currIdx + 1) % 4];
        setRobotState({ ...state });
      } else if (cmd.type === 'REPEAT') {
        const loops = cmd.count || Infinity;
        let loopCounter = 0;
        
        const startTime = Date.now();
        
        while (loopCounter < loops) {
           if (!runningRef.current) return { state, newStatus: 'idle', trace };
           
           if (Date.now() - startTime > 3000 && (cmd.children?.length === 0 || !cmd.children)) {
              setErrorMessage("Empty loop spins forever! A REPEAT block needs commands inside.");
              setActiveCommandId(cmd.id);
              return { state, newStatus: 'infinite-loop', trace };
           }

           const result = await executeCommandStep(cmd.children || [], state, trace, stepCountRef);
           state = result.state;
           trace = result.trace;
           if (result.newStatus !== 'idle') {
             return result; // Crash, success, or interrupted
           }
           loopCounter++;
        }
      } else if (cmd.type === 'IF_OBSTACLE') {
        // Check if there is a wall directly ahead
        let nextX = state.x;
        let nextY = state.y;
        if (state.dir === 'N') nextY -= 1;
        if (state.dir === 'E') nextX += 1;
        if (state.dir === 'S') nextY += 1;
        if (state.dir === 'W') nextX -= 1;

        const cell = level.grid[nextY]?.[nextX];
        const hasObstacle = !cell || cell === 'W';
        
        if (hasObstacle && cmd.children && cmd.children.length > 0) {
           const result = await executeCommandStep(cmd.children, state, trace, stepCountRef);
           state = result.state;
           trace = result.trace;
           if (result.newStatus !== 'idle') {
             return result;
           }
        }
      }
    }
    
    return { state, newStatus: 'idle', trace };
  };

  const runWithDelay = async (commands: CommandNode[]) => {
    reset();
    runningRef.current = true;
    setStatus('running');
    
    // Initial delay so user sees start
    await new Promise(r => { timeoutRef.current = window.setTimeout(r, 400) });
    if (!runningRef.current) return;

    const stepCountRef = { count: 0 };
    const { state, newStatus, trace } = await executeCommandStep(commands, { x: level.startPos.x, y: level.startPos.y, dir: level.startDir }, [{ x: level.startPos.x, y: level.startPos.y }], stepCountRef);
    
    if (newStatus === 'success') {
      setStatus('success');
      setActiveCommandId(null);
    } else if (newStatus === 'idle') {
       // Finished commands but not at exit
       const isAtExit = level.grid[state.y]?.[state.x] === 'X';
       if (!isAtExit) {
          setStatus('incomplete');
          setErrorMessage("Robot ran out of instructions before reaching the exit!");
       } else {
          setStatus('success');
       }
       setActiveCommandId(null);
    } else {
      setStatus(newStatus);
    }
    runningRef.current = false;
  };

  const runProgram = (commands: CommandNode[]) => {
    runWithDelay(commands);
  };

  return {
    status,
    robotState,
    activeCommandId,
    pathTrace,
    runProgram,
    reset,
    errorMessage
  };
}
