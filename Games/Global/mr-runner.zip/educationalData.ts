export interface Hint {
    title: string;
    content: string;
}

export interface QuizQuestion {
    question: string;
    options: string[];
    correctIndex: number;
}

export interface Subject {
    id: string;
    name: string;
    targetWord: string[];
    hints: Hint[];
    quizzes: QuizQuestion[];
}

export const SUBJECTS: Record<string, Subject> = {
    MATH: {
        id: 'MATH',
        name: 'Mathematics',
        targetWord: ['M','A','T','H'],
        hints: [
            { title: 'Geometry', content: 'A regular polygon has equal sides and equal angles. A circle has 360 degrees.' },
            { title: 'Algebra', content: 'In algebra, letters are used to represent unknown numbers, called variables.' },
            { title: 'Arithmetic', content: 'The order of operations is PEMDAS: Parentheses, Exponents, Multiplication/Division, Addition/Subtraction.' },
            { title: 'Fractions', content: 'A fraction represents a part of a whole. The top is the numerator, the bottom is the denominator.' }
        ],
        quizzes: [
            { question: 'What is the sum of angles in a triangle?', options: ['90°', '180°', '360°', '270°'], correctIndex: 1 },
            { question: 'What is 8 x 7?', options: ['54', '56', '64', '42'], correctIndex: 1 },
            { question: 'Solve for x: 2x = 10', options: ['5', '8', '12', '20'], correctIndex: 0 }
        ]
    },
    SCIENCE: {
        id: 'SCIENCE',
        name: 'Science',
        targetWord: ['A','T','O','M'],
        hints: [
            { title: 'Biology', content: 'Mitochondria is the powerhouse of the cell, generating most of its chemical energy.' },
            { title: 'Chemistry', content: 'Water is composed of two hydrogen atoms and one oxygen atom (H2O).' },
            { title: 'Physics', content: 'Newton\'s first law states an object in motion stays in motion unless acted upon by a force.' },
            { title: 'Astronomy', content: 'Jupiter is the largest planet in our solar system.' }
        ],
        quizzes: [
            { question: 'What gas do plants absorb during photosynthesis?', options: ['Oxygen', 'Nitrogen', 'Carbon Dioxide', 'Hydrogen'], correctIndex: 2 },
            { question: 'What is the chemical symbol for Gold?', options: ['Go', 'Au', 'Ag', 'Gd'], correctIndex: 1 },
            { question: 'Which planet is known as the Red Planet?', options: ['Venus', 'Mars', 'Jupiter', 'Saturn'], correctIndex: 1 }
        ]
    },
    HISTORY: {
        id: 'HISTORY',
        name: 'History',
        targetWord: ['P','A','S','T'],
        hints: [
            { title: 'Ancient Egypt', content: 'The Great Pyramid of Giza was built as a tomb for the Pharaoh Khufu.' },
            { title: 'Space Race', content: 'Apollo 11 was the first manned mission to land on the Moon in 1969.' },
            { title: 'Inventors', content: 'Thomas Edison is credited with inventing the first practical incandescent light bulb.' },
            { title: 'Civilizations', content: 'The Roman Empire surrounded the Mediterranean Sea and lasted for hundreds of years.' }
        ],
        quizzes: [
            { question: 'Who was the first President of the United States?', options: ['Abraham Lincoln', 'Thomas Jefferson', 'George Washington', 'John Adams'], correctIndex: 2 },
            { question: 'In what year did World War II end?', options: ['1945', '1939', '1918', '1960'], correctIndex: 0 },
            { question: 'Which civilization built Machu Picchu?', options: ['Aztec', 'Maya', 'Inca', 'Olmec'], correctIndex: 2 }
        ]
    }
};
